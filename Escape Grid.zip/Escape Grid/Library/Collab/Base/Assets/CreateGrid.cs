﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CreateGrid : MonoBehaviour
{

    public GameObject prefab;
	public FollowTarget camara;
    private List<List<GameObject>> grid;
	private int x = 9, y = 9;

    void Awake(){


        grid = new List<List<GameObject>>();

        for (int i = 0; i < 20; i++)
        {

			List<GameObject> row = new List<GameObject>();

            for (int j = 0; j < 20; j++)
            {

                GameObject obj = Instantiate(prefab);
                obj.transform.SetParent(this.transform);
				obj.GetComponent<MeshRenderer> ().enabled = false;
                obj.transform.localPosition = new Vector3((float)j, 0f, -(float)i);
                row.Add(obj);

            }

            grid.Add(row);
        }
		grid[9][9].GetComponent<MeshRenderer> ().enabled = true;
		grid[9][9].GetComponent<MeshRenderer> ().material.color = Color.green;

		camara.target = grid [9] [9].transform;
    }

	void Update(){

		int a = x;
		int b = y;

		if (Input.GetKeyDown (KeyCode.UpArrow)) {


			a--;
			a = Mathf.Clamp (a, 0, 19);

			grid[a][b].GetComponent<MeshRenderer> ().enabled = true;
			camara.target = grid [a] [b].transform;
			x = a;
			y = b;
		}
	}
}