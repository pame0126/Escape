﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CreateGrid : MonoBehaviour
{

    public GameObject prefab;
    private List<List<GameObject>> grid;

    void Awake(){

        grid = new List<List<GameObject>>();

        for (int i = 0; i < 20; i++)
        {

			List<GameObject> row = new List<GameObject>();

            for (int j = 0; j < 20; j++)
            {

                GameObject obj = Instantiate(prefab);
                obj.transform.SetParent(this.transform);
                obj.transform.localPosition = new Vector3((float)j, 0f, -(float)i);
                obj.transform.GetComponent<MeshRenderer>().enabled = false;
                row.Add(obj);

            }

            grid.Add(row);
        }
    }
}