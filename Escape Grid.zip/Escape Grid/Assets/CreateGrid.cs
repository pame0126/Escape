﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CreateGrid : MonoBehaviour
{

    public GameObject[] prefabs;
	public FollowTarget camara;
    private List<List<GameObject>> grid;
	private int x = 9, y = 9;

    void Awake(){


        grid = new List<List<GameObject>>();

        for (int i = 0; i < 20; i++)
        {
            Quaternion rot = Quaternion.EulerAngles(0, 90, 0);
            GameObject cosa = (GameObject)Instantiate(Resources.Load("MiCosa"), transform.position + Vector3.zero, Quaternion.identity, transform);

			List<GameObject> row = new List<GameObject>();

            for (int j = 0; j < 20; j++)
            {
                GameObject prefab = prefabs[Random.Range(0, 5)];
                GameObject obj = Instantiate(prefab);
                obj.transform.SetParent(this.transform);
				obj.GetComponent<MeshRenderer> ().enabled = false;
                obj.transform.localPosition = new Vector3((float)j, 0f, -(float)i);
                row.Add(obj);

            }

            grid.Add(row);
        }
		grid[9][9].GetComponent<MeshRenderer> ().enabled = true;

		camara.target = grid [9] [9].transform;
    }

	void Update(){

		int a = x;
		int b = y;

		if (Input.GetKeyDown (KeyCode.UpArrow)) {

            grid[a][b].GetComponent<MeshRenderer>().material.color = Color.white;

            a--;
			a = Mathf.Clamp (a, 0, 19);

			grid[a][b].GetComponent<MeshRenderer> ().enabled = true;
            grid[a][b].GetComponent<MeshRenderer>().material.color = Color.green;
            camara.target = grid [a] [b].transform;
			x = a;
			y = b;
		}


		if (Input.GetKeyDown (KeyCode.DownArrow)) {

            grid[a][b].GetComponent<MeshRenderer>().material.color = Color.white;


            a++;
			a = Mathf.Clamp (a, 0, 19);

			grid[a][b].GetComponent<MeshRenderer> ().enabled = true;

            grid[a][b].GetComponent<MeshRenderer>().material.color = Color.green;


            camara.target = grid [a] [b].transform;
			x = a;
			y = b;
		}

		if (Input.GetKeyDown (KeyCode.LeftArrow)) {

            grid[a][b].GetComponent<MeshRenderer>().material.color = Color.white;


            b--;
			b = Mathf.Clamp (b, 0, 19);

			grid[a][b].GetComponent<MeshRenderer> ().enabled = true;

            grid[a][b].GetComponent<MeshRenderer>().material.color = Color.green;


            camara.target = grid [a] [b].transform;
			x = a;
			y = b;
		}

		if (Input.GetKeyDown (KeyCode.RightArrow)) {

            grid[a][b].GetComponent<MeshRenderer>().material.color = Color.white;


            b++;
			b = Mathf.Clamp (b, 0, 19);

			grid[a][b].GetComponent<MeshRenderer> ().enabled = true;

            grid[a][b].GetComponent<MeshRenderer>().material.color = Color.green;

            camara.target = grid [a] [b].transform;
			x = a;
			y = b;
		}
	}
}